=== Maester ===
Contributors: feehatheme
Requires at least: 5.0
Tested up to: 5.2
Requires PHP: 5.6
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Maester Lite is the perfect theme for LMS based eLearning & Educational Websites

== Description ==

Maester LMS theme is beautifully and logically designed for all kind of educational platforms. You can build any kind of eLearning platform using Maester theme, it's an all-in-one WordPress LMS theme based on Tutor LMS Plugin to create & sell online courses. Maester Lite LMS theme is perfectly built for individual educators, schools, training institutes, coachinc centers and any other type of academises


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright  ==

Maester Lite WordPress Theme, Copyright 2019 FeehaTheme
Maester Lite is distributed under the terms of the GNU GPL

Maester Lite bundles the following third-party resources:

	Font Awesome by Dave Gandy
    Licenses: SIL OFL 1.1, MIT, CC BY 3.0
    Source: https://github.com/FortAwesome/Font-Awesome

    Bootstrap by Twitter, Copyright (c) 2011-2019 Twitter, Inc.
    Licenses: MIT, CC BY 3.0
    Source: https://github.com/twbs/bootstrap

    TGM-Plugin-Activation, Copyright (c) 2011, Thomas Griffin
    License: GNU GPL, Version 2
    Source: https://github.com/TGMPA/TGM-Plugin-Activation

    jQuery Nice Select, Copyright (c) 2017 Hernán Sartorio
    License: MIT
    Source: https://github.com/hernansartorio/jquery-nice-select

    Screenshot images
    Licenses: CC0 Public Domain
	https://pxhere.com/en/photo/723648

== Changelog ==

= 1.2.4 =
* Initial release



