<?php
	/**
	 * The template for displaying the empty footer
	 *
	 * Contains the closing of the #page div and all content after.
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
	 *
	 * @package Maester
	 */

?>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>